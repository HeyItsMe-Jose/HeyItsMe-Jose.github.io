#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
sender.setup("localhost", 12345);
receiver.setup(12345);

ofBackground(0);

}

//--------------------------------------------------------------
void ofApp::update(){
  while(receiver.hasWaitingMessages()){
      ofxOscMessage msg;
      receiver.getNextMessage(msg);
      if (msg.getAddress() == "/x"){
        oscx = msg.getArgAsFloat(0);
      }
      if (msg.getAddress() == "/y"){
        oscy = msg.getArgAsFloat(0);
    }
  }
}

//--------------------------------------------------------------
void ofApp::draw(){

  ofEnableBlendMode(OF_BLENDMODE_ALPHA);
      int r = 255;
      int g = 255;
      int b = 255;

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*10);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*9);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*8);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*7);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*6);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*5);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*4);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*3);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*2);

      ofSetColor(r, 0, 0, 128);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2, oscx*1);

      ofSetColor(0, g, 0, 128);
      ofFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/2.05, oscy*9);

      ofSetColor(0, 0, b, 128);
      ofFill();
      ofDrawCircle(ofGetWidth()/2, ofGetHeight()/1.95, oscy*10);

      ofSetColor(r, g, b, 200);
      ofFill();
      ofDrawCircle(ofGetWidth()/1.95, ofGetHeight()/2, oscy*1);

      ofSetColor(r, g, b, 200);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/1.95, ofGetHeight()/2, oscy*2);

      ofSetColor(r, g, b, 200);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/1.95, ofGetHeight()/2, oscy*4);

      ofSetColor(r, g, b, 200);
      ofNoFill();
      ofDrawCircle(ofGetWidth()/1.95, ofGetHeight()/2, oscy*3);


}
//--------------------------------------------------------------
void ofApp::exit(){

}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseScrolled(int x, int y, float scrollX, float scrollY){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){

}
